﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp10
{
    internal class Program
    {
        static void Main(string[] args)
        {
                // ===== Variables =====
                string name = "";
                string category = "";
                double amount = 0;
                int count = 0;
                double total = 0;
                double average = 0;
                bool keepGoing = true;
                // ======================

                Console.WriteLine("****** Welcome to Monthly Expense Tracker ******\n");

                Console.Write("Enter your name: ");
                name = Console.ReadLine();

                while (keepGoing)
                {
                    Console.Write("Enter expense category: ");
                    category = Console.ReadLine();

                    Console.Write("Enter amount (or -1 to quit): ");
                    amount = Convert.ToDouble(Console.ReadLine());

                    if (amount == -1)
                    {
                        keepGoing = false;
                        break;
                    }

                    if (amount <= 0)
                    {
                        Console.WriteLine("Amount must be positive.\n");
                        continue;
                    }

                    total += amount;
                    count++;
                }

                if (count > 0)
                {
                    average = total / count;
                }

                // ===== Summary =====
                Console.WriteLine("\n========== MONTHLY EXPENSE SUMMARY ==========");
                Console.WriteLine("Name:                    " + name);
                Console.WriteLine("Total Entries:           " + count);
                Console.WriteLine("Total Amount Spent:      $" + total.ToString("F2"));
                Console.WriteLine("Average Expense:         $" + average.ToString("F2"));
                Console.WriteLine("============================================");
                Console.WriteLine("Thank you for using the Monthly Expense Tracker!");
            }
        }
    }