﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp9
{
    internal class Program
    {
        static void Main(string[] args)
        {       // Variable declarations and initializations
                string name = "", gender = "", projectName = "", highestProject = "";
                int age = 0, heightFeet = 0, heightInches = 0, projectCount = 0;
                double weight = 0.0, hours = 0.0, rate = 0.0, income = 0.0;
                double totalIncome = 0.0, highestIncome = 0.0, averageIncome = 0.0;

                Console.WriteLine("****** Welcome to Freelance Project Income Tracker ******");

                // Personal Info
                Console.Write("Enter your name: ");
                name = Console.ReadLine();

                Console.Write("Enter your age: ");
                age = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter your gender (male/female): ");
                gender = Console.ReadLine();

                Console.Write("Enter your height - feet: ");
                heightFeet = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter your height - inches: ");
                heightInches = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter your weight in pounds: ");
                weight = Convert.ToDouble(Console.ReadLine());

                // Project Info
                Console.Write("How many projects would you like to enter? ");
                projectCount = Convert.ToInt32(Console.ReadLine());

                for (int i = 1; i <= projectCount; i++)
                {
                    Console.WriteLine($"\nProject #{i}:");

                    Console.Write("Enter project name: ");
                    projectName = Console.ReadLine();

                    Console.Write("Enter hours worked: ");
                    hours = Convert.ToDouble(Console.ReadLine());

                    Console.Write("Enter hourly rate: ");
                    rate = Convert.ToDouble(Console.ReadLine());

                    income = hours * rate;
                    totalIncome += income;

                    if (income > highestIncome)
                    {
                        highestIncome = income;
                        highestProject = projectName;
                    }
                }

                averageIncome = totalIncome / projectCount;

                // Summary
                Console.WriteLine("\n========== FREELANCE INCOME SUMMARY ==========");
                Console.WriteLine($"Freelancer Name:         {name}");
                Console.WriteLine($"Projects Logged:         {projectCount}");
                Console.WriteLine($"Total Income:            ${totalIncome:F2}");
                Console.WriteLine($"Average Project Income:  ${averageIncome:F2}");
                Console.WriteLine($"Highest-Earning Project: {highestProject} (${highestIncome:F2})");
                Console.WriteLine("==============================================");
                Console.WriteLine("Thank you for using the Income Tracker!");
            }
        }
    }