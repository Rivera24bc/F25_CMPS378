﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string name = "";
            string gender = "";
            string status = "";
            int age = 0;
            int heightFeet = 0;
            int heightInches = 0;
            int totalInches = 0;
            double weight = 0;
            double BMI = 0;

            Console.Write("Please enter your name: ");
            name = Console.ReadLine();

            Console.Write("Please enter your age: ");
            age = Convert.ToInt32(Console.ReadLine());

            Console.Write("Please enter your gender: ");
            gender = Console.ReadLine();

            Console.Write("Please enter your height in feet: ");
            heightFeet = Convert.ToInt32(Console.ReadLine());

            Console.Write("Please enter your height in inches: ");
            heightInches = Convert.ToInt32(Console.ReadLine());

            Console.Write("Please enter your weight in pounds: ");
            weight = Convert.ToDouble(Console.ReadLine());

            totalInches = (heightFeet * 12) + heightInches;
            BMI = 703 * weight / Math.Pow(totalInches, 2); //Used Chat gpt for only this section because i don't know how to inches^2.

            if (BMI < 16)
            {
                status = "Servere Thinness";
            }
            else if(BMI>=16 && BMI<17)
            {
                status= "Moderate Thinness";
            }
            else if(BMI>=17 && BMI<18.5)
            {
                status = "Mild Thinness";
            }
            else if(BMI>=18.5 && BMI<25)
            {
                status = "Normal";
            }
            else if(BMI>=25 &&  BMI<30)
            {
                status = "Overweight";
            }
            else if(BMI>= 30 && BMI<35)
            {
                status = "Obese Class I";
            }
            else if(BMI>=35 &&  BMI<40)
            {
                status = "Obese Class II";
            }
            else if (BMI>40)
            {
               status = "Obese Class III";
            }
            else
            {
                Console.WriteLine();
            }

            Console.WriteLine("Hi, " + name);
            Console.WriteLine("You are a " + gender + ". You are " + age + " years old.");
            Console.WriteLine("You are currently " + heightFeet + "'" + heightInches + " and weight " + weight + " pounds.");
            Console.WriteLine("Your BMI is " + BMI + " which is " + status + ".");
            Console.WriteLine("Thank you for using the BMI Calculator!");
        }
    }
}
