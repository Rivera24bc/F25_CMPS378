﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {
                Console.WriteLine("-- Welcome to LADWP Utility Bill Calculator ---");

                Console.Write("Enter your name: ");
                string name = Console.ReadLine();

                Console.WriteLine("CMPS 378: C# Programming Fall 2025");

                Console.Write("Enter electricity usage in kWh: ");
                int kWh = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter water usage in HCF: ");
                int hcf = Convert.ToInt32(Console.ReadLine());

                double electricityRate;
                if (kWh <= 199)
                    electricityRate = 0.13;
                else if (kWh <= 499)
                    electricityRate = 0.17;
                else if (kWh <= 999)
                    electricityRate = 0.21;
                else
                    electricityRate = 0.26;

                double waterRate;
                if (hcf <= 9)
                    waterRate = 2.30;
                else if (hcf <= 24)
                    waterRate = 3.10;
                else if (hcf <= 39)
                    waterRate = 4.20;
                else
                    waterRate = 5.15;

                double electricityCharge = kWh * electricityRate;
                double waterCharge = hcf * waterRate;
                double totalBill = electricityCharge + waterCharge;

                Console.WriteLine("\n--- LADWP MONTHLY BILL ---");
                Console.WriteLine($"Customer Name: {name}");
                Console.WriteLine($"Electricity Usage: {kWh} kWh");
                Console.WriteLine($"Rate Applied: ${electricityRate:F2} per kWh");
                Console.WriteLine($"Electricity Charge: ${electricityCharge:F2}");
                Console.WriteLine($"Water Usage: {hcf} HCF");
                Console.WriteLine($"Rate Applied: ${waterRate:F2} per HCF");
                Console.WriteLine($"Water Charge: ${waterCharge:F2}");
                Console.WriteLine($"Total Amount Due: ${totalBill:F2}");
                Console.WriteLine("Thank you for using LADWP!");
            }
        }
    }
