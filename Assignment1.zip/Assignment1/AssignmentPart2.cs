﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
                string tryAgain = "Y";

                Console.WriteLine("Welcome to Birthday Date Meaning Generator!");

                while (tryAgain.ToUpper() == "Y")
                {
                    // Ask for month
                    Console.Write("Please enter the month of your birthday: ");
                    string month = Console.ReadLine().ToLower();

                    // Ask for day
                    Console.Write("Please enter the day of your birthday (1-31): ");
                    int day = Convert.ToInt32(Console.ReadLine());

                    // Ask for year
                    Console.Write("Please enter the year of your birthday (2000-2023): ");
                    int year = Convert.ToInt32(Console.ReadLine());

                    // Month meaning
                    switch (month)
                    {
                        case "january": Console.WriteLine("January means strength and friendship."); break;
                        case "february": Console.WriteLine("February means peace and stability."); break;
                        case "march": Console.WriteLine("March means courage and hope."); break;
                        case "april": Console.WriteLine("April means purity and innocence."); break;
                        case "may": Console.WriteLine("May means love and happiness."); break;
                        case "june": Console.WriteLine("June means beauty and love."); break;
                        case "july": Console.WriteLine("July means passion and love."); break;
                        case "august": Console.WriteLine("August means strength and moral integrity."); break;
                        case "september": Console.WriteLine("September means wisdom and loyalty."); break;
                        case "october": Console.WriteLine("October means faithfulness and confidence."); break;
                        case "november": Console.WriteLine("November means friendship and joy."); break;
                        case "december": Console.WriteLine("December means success and good fortune."); break;
                        default: Console.WriteLine("Unknown month."); break;
                    }

                    switch (day)
                    {
                        case 1: Console.WriteLine("The 1st means Self-Starter."); break;
                        case 2: Console.WriteLine("The 2nd means Peacemaker."); break;
                        case 3: Console.WriteLine("The 3rd means Creative Communicator."); break;
                        case 4: Console.WriteLine("The 4th means Dependable and Rational."); break;
                        case 5: Console.WriteLine("The 5th means Flexible and Adventurous."); break;
                        case 6: Console.WriteLine("The 6th means Nurturer and Healer."); break;
                        case 7: Console.WriteLine("The 7th means Seeker of Truth."); break;
                        case 8: Console.WriteLine("The 8th means Ambitious and Powerful."); break;
                        case 9: Console.WriteLine("The 9th means Compassionate and Giving."); break;
                        case 10: Console.WriteLine("The 10th means Natural Leader."); break;
                        case 11: Console.WriteLine("The 11th means Intuitive and Insightful."); break;
                        case 12: Console.WriteLine("The 12th means Creative and Expressive."); break;
                        case 13: Console.WriteLine("The 13th means Practical and Optimistic."); break;
                        case 14: Console.WriteLine("The 14th means Open-Minded and Wise."); break;
                        case 15: Console.WriteLine("The 15th means Loving and Social."); break;
                        case 16: Console.WriteLine("The 16th means Inquisitive and Perceptive."); break;
                        case 17: Console.WriteLine("The 17th means Independent and Efficient."); break;
                        case 18: Console.WriteLine("The 18th means Altruistic and Ambitious."); break;
                        case 19: Console.WriteLine("The 19th means Risk-Taker and Self-Sufficient."); break;
                        case 20: Console.WriteLine("The 20th means Harmonious and Sensitive."); break;
                        case 21: Console.WriteLine("The 21st means Charismatic and Creative."); break;
                        case 22: Console.WriteLine("The 22nd means Master Builder and Visionary."); break;
                        case 23: Console.WriteLine("The 23rd means Energetic and Optimistic."); break;
                        case 24: Console.WriteLine("The 24th means Loyal and Nurturing."); break;
                        case 25: Console.WriteLine("The 25th means Analytical and Curious."); break;
                        case 26: Console.WriteLine("The 26th means Innovative and Caring."); break;
                        case 27: Console.WriteLine("The 27th means Tolerant and Wise."); break;
                        case 28: Console.WriteLine("The 28th means Cooperative Leader."); break;
                        case 29: Console.WriteLine("The 29th means Insightful and Connected."); break;
                        case 30: Console.WriteLine("The 30th means Creative and Uplifting."); break;
                        case 31: Console.WriteLine("The 31st means Practical and Imaginative."); break;
                        default: Console.WriteLine("Invalid day."); break;
                    }

                switch (year)
                {
                    case 2000: Console.WriteLine("The year 2000 means you are a Millennial."); break;
                    case 2001: Console.WriteLine("The year 2001 means you are tech-savvy."); break;
                    case 2002: Console.WriteLine("The year 2002 means you are a dreamer."); break;
                    case 2003: Console.WriteLine("The year 2003 means you are creative and curious."); break;
                    case 2004: Console.WriteLine("The year 2004 means you are grounded and wise."); break;
                    case 2005: Console.WriteLine("The year 2005 means you are adventurous and bold."); break;
                    case 2006: Console.WriteLine("The year 2006 means you are compassionate and kind."); break;
                    case 2007: Console.WriteLine("The year 2007 means you are analytical and thoughtful."); break;
                    case 2008: Console.WriteLine("The year 2008 means you are ambitious and driven."); break;
                    case 2009: Console.WriteLine("The year 2009 means you are spiritual and intuitive."); break;
                    case 2010: Console.WriteLine("The year 2010 means you are innovative and expressive."); break;
                    case 2011: Console.WriteLine("The year 2011 means you are insightful and empathetic."); break;
                    case 2012: Console.WriteLine("The year 2012 means you are balanced and peaceful."); break;
                    case 2013: Console.WriteLine("The year 2013 means you are energetic and optimistic."); break;
                    case 2014: Console.WriteLine("The year 2014 means you are thoughtful and creative."); break;
                    case 2015: Console.WriteLine("The year 2015 means you are confident and curious."); break;
                    case 2016: Console.WriteLine("The year 2016 means you are nurturing and loyal."); break;
                    case 2017: Console.WriteLine("The year 2017 means you are visionary and independent."); break;
                    case 2018: Console.WriteLine("The year 2018 means you are generous and wise."); break;
                    case 2019: Console.WriteLine("The year 2019 means you are expressive and bold."); break;
                    case 2020: Console.WriteLine("The year 2020 means you are resilient and thoughtful."); break;
                    case 2021: Console.WriteLine("The year 2021 means you are adaptable and creative."); break;
                    case 2022: Console.WriteLine("The year 2022 means you are intuitive and kind."); break;
                    case 2023: Console.WriteLine("The year 2023 means you are future-focused and innovative."); break;
                    default: Console.WriteLine("Year out of range."); break;
                }
                    Console.Write("Would you like to try another one? (Y/N): ");
                    tryAgain = Console.ReadLine();
                }

                Console.WriteLine("Thanks for playing!");
            }
        }
    }
