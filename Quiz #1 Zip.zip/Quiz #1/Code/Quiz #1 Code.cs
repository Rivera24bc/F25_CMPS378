﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string customerName, packageCode, drinkChoice, comboName;
            int quantity;
            double pricePerItem, subtotal, tax, total;
            bool drinkIncluded, freeDessert;

          // Constants
          const double TAX_RATE = 0.095;

          // Welcome Message & Menu
          Console.WriteLine("****** Welcome to Taco Loco POS System ******");
          Console.WriteLine("Menu:");
          Console.WriteLine("A - 3 Tacos Combo - $7.00 / $9.00 with drink");
          Console.WriteLine("B - Burrito Meal - $8.50 / $10.50 with drink");
          Console.WriteLine("C - Quesadilla Special - $6.00 / $8.00 with drink");
          Console.WriteLine("D - Loaded Nachos - $5.75 / $7.75 with drink");

          // User Input
          Console.Write("Enter your name: ");
          customerName = Console.ReadLine();

          Console.Write("Enter your package code (A/B/C/D): ");
          packageCode = Console.ReadLine().ToUpper();

          Console.Write("Would you like to add a drink? (Y/N): ");
          drinkChoice = Console.ReadLine().ToUpper();

          Console.Write("How many combos would you like? ");
          quantity = Convert.ToInt32(Console.ReadLine());

          // Variables
          comboName = "";
          pricePerItem = 0.0;
          drinkIncluded = (drinkChoice == "Y");

          // Determine combo and price
          switch (packageCode)
          {
           case "A":
             comboName = "3 Tacos Combo";
             pricePerItem = drinkIncluded ? 9.00 : 7.00;
           break;
           case "B":
             comboName = "Burrito Meal";
             pricePerItem = drinkIncluded ? 10.50 : 8.50;
           break;
           case "C":
             comboName = "Quesadilla Special";
             pricePerItem = drinkIncluded ? 8.00 : 6.00;
           break;
           case "D":
             comboName = "Loaded Nachos";
             pricePerItem = drinkIncluded ? 7.75 : 5.75;
           break;
           default:
            Console.WriteLine("Invalid package code. Exiting...");
           return;
          }

           // Calculations
           subtotal = pricePerItem * quantity;
           tax = subtotal * TAX_RATE;
           total = subtotal + tax;
           freeDessert = subtotal >= 20.00;

           // Receipt
           Console.WriteLine("\n--- TACO LOCO RECEIPT ---");
           Console.WriteLine($"Customer Name: {customerName}");
           Console.WriteLine($"Combo Ordered: {comboName}");
           Console.WriteLine($"Drink Included: {(drinkIncluded ? "Yes" : "No")}");
           Console.WriteLine($"Quantity: {quantity}");
           Console.WriteLine("-----------------------------------------");
           Console.WriteLine($"Price Per Item: ${pricePerItem:F2}");
           Console.WriteLine($"Subtotal: ${subtotal:F2}");
           Console.WriteLine($"Tax (9.5%): ${tax:F2}");
           Console.WriteLine("-----------------------------------------");
           Console.WriteLine($"Total Cost: ${total:F2}");

           if (freeDessert)
           {
           Console.WriteLine("Congratulations! You get a free dessert!");
           }

           Console.WriteLine("=========================================");
           Console.WriteLine("Thank you for supporting Taco Loco!");
           }
        }
    }